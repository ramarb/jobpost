<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>

<form method="post" enctype="multipart/form-data" action="<?php echo base_url('vacancies/test')?>">
    <input type="file" name="file" />
    <input type="submit" value="Upload" />
</form>

</body>
</html>