<h1>Dashboard</h1>
<a class="btn btn-block btn-info" href="<?php echo base_url($role.'/account/edit')?>">Profile</a>
<a class="btn btn-block btn-info" href="<?php echo base_url($role.'/vacancies/mylist')?>">My Vacancies</a>
<a class="btn btn-block btn-info" href="<?php echo base_url($role.'/vacancies/applicants')?>">Applicants</a>
<a class="btn btn-block btn-info" href="<?php echo base_url($role.'/talents')?>">Find Talents</a>


