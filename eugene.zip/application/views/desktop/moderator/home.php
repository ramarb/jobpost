<h1>Dashboard</h1>
<a class="btn btn-block btn-info" href="#">Edit Profile</a>
<a class="btn btn-block btn-info" href="<?php echo base_url(strtolower($role) . '/users/mylist')?>">Users</a>
<a class="btn btn-block btn-info" href="<?php echo base_url(strtolower($role) . '/industries/mylist')?>">Industries</a>
<a class="btn btn-block btn-info" href="<?php echo base_url(strtolower($role) . '/categories/mylist')?>">Categories</a>
<a class="btn btn-block btn-info" href="<?php echo base_url(strtolower($role) . '/vacancies/mylist')?>">Vacancies</a>